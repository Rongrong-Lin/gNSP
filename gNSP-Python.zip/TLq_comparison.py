import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import brentq


def get_tl12_data(nu, epsilon, tau_range):
    # 1. 求解 a 和阈值 tau_bar
    def quintic_a(a):
        return a ** 3 * (epsilon + a)**2 - nu * (epsilon + 1) * (2 * a + epsilon)

    high = 1.5  # 需要根据具体问题设定一个合理的上界
    a_root = brentq(quintic_a, 0, high, xtol=1e-8)
    print(a_root)
    bar_u = a_root ** 2
    bar_tau = (bar_u * (4 * a_root + 3 * epsilon)) / (2 * (2 * a_root + epsilon))

    # 2. 辅助计算函数
    def get_v_star(tau_abs):
        inner_cos = (epsilon * (5 * tau_abs - epsilon ** 2)) / (epsilon ** 2 + 5 * tau_abs) ** 1.5
        inner_cos = np.clip(inner_cos, -1, 1)
        return -epsilon / 5 + (2 / 5) * np.sqrt(epsilon ** 2 + 5 * tau_abs) * np.cos(1 / 3 * np.arccos(inner_cos))

    def g_func(v, tau_abs):
        return v * (epsilon + v) ** 2 * (v ** 2 - tau_abs) + 0.5 * nu * epsilon * (epsilon + 1)

    def bisection_tl12(tau_abs):
        v_min = get_v_star(tau_abs)
        v_max = np.sqrt(tau_abs)
        # 初始边界检查（安全防护）
        # if g_func(v_min, tau_abs) * g_func(v_max, tau_abs) >= 0:
        #     return v_max  # 如果不异号，通常说明接近阈值，返回边界值
        a, b = v_min, v_max
        for _ in range(50):
            c = (a + b) / 2
            # 核心逻辑：检查左侧区间是否有根
            if g_func(a, tau_abs) * g_func(c, tau_abs) < 0:
                b = c
            else:
                a = c
            if (b - a) < 1e-8:
                break
        return (a + b) / 2

    # 3. 计算序列
    prox_vals = []
    for t in tau_range:
        abs_t = abs(t)
        if abs_t < bar_tau:
            prox_vals.append(0.0)
        else:
            v_tau = bisection_tl12(abs_t)
            prox_vals.append(np.sign(t) * (v_tau ** 2))

    return prox_vals, bar_tau

def get_l12_standard_data(nu, tau_range):
    """计算标准 L1/2 算子数据作为对比"""
    prox_vals = []
    threshold = 1.5 * np.power(nu, 2 / 3)  # 标准 L1/2 的跳跃阈值

    for t in tau_range:
        abs_t = abs(t)
        if abs_t > threshold:
            # 标准 L1/2 的解析解公式
            theta = np.arccos((- 3 * np.sqrt(3) / 4) * nu * np.power(abs_t, -1.5))
            val = (2 / 3) * t * (1 + np.cos(2 * theta / 3))
            prox_vals.append(val)
        else:
            prox_vals.append(0.0)
    return prox_vals, threshold

def plot_combined_prox(param_list):
    """
    param_list: 格式为 [(nu1, eps1), (nu2, eps2), ...]
    """
    plt.figure(figsize=(12, 8))

    # 设定一个足够大的横坐标范围，涵盖所有组合
    tau_vals = np.linspace(-3, 3, 1000)
    # 1. 绘制 y = x 参照线
    plt.plot(tau_vals, tau_vals, color='gray', lw=1, ls=':')

    # 2. 绘制标准 L1/2 算子 (取一个代表性的 nu 值，例如 1.0)
    l12_y, l12_tau = get_l12_standard_data(nu=1.0, tau_range=tau_vals)
    plt.plot(tau_vals, l12_y, color='black', lw=2, ls='-.',
             label=rf'$\ell_{1/2}^{1/2}$ : $\nu=1.0$ ($\bar{{\tau}}={l12_tau:.6f}$)')

    # 3. 循环绘制 TL 1/2 算子
    tl_colors = ["#0071B2FF", '#D55E00', '#009E73', '#CC79A7', '#E69F00', "#56B4E9", "#F0E442FF", "#000000FF"]

    for idx, (nu, eps) in enumerate(param_list):
        prox_y, b_tau = get_tl12_data(nu, eps, tau_vals)
        plt.plot(tau_vals, prox_y, lw=2, ls='--', color=tl_colors[idx % len(tl_colors)],
                 label=rf'$\rm TL{{1/2}}: \nu={nu}, \epsilon={eps}$ ($\bar{{\tau}}={b_tau:.6f}$)')

    plt.axhline(0, color='black', lw=1)
    plt.axvline(0, color='black', lw=1)
    plt.xlabel(r'$\tau$', fontsize=12)
    plt.ylabel(r'$\rm prox_{\nu {\rm TL1/2}}(\tau)$', fontsize=12)
    plt.legend(loc='upper left', fontsize=10)

    # 保存图片
    plt.savefig('ProxTL1over2.png', dpi=300, bbox_inches='tight')
    plt.show()


# --- 调用示例 ---
#(nu,eps)
params = [
    (0.5, 1.0),
    (0.5, 2.0),
    (0.5, 4.0),
    (1.0, 1.0),
    (1.0, 2.0),
    (1.0, 4.0)
]

plot_combined_prox(params)