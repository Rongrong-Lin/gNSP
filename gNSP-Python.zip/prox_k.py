import numpy as np
from scipy.special import lambertw
from scipy.optimize import brentq
import math

#TL1/2 shrinkage
# 1. 求解 a 和阈值 tau_bar
def quintic_a(a,nu,epsilon):
    return a ** 3 * (epsilon + a)**2 - nu * (epsilon + 1) * (2 * a + epsilon)

def get_bar_tau(nu,epsilon):
    high = 1.5  # 需要根据具体问题设定一个合理的上界
    a_root = brentq(quintic_a, 0, high, args=(nu, epsilon), xtol=1e-8)
    bar_u = a_root ** 2
    bar_tau = (bar_u * (4 * a_root + 3 * epsilon)) / (2 * (2 * a_root + epsilon))
    return bar_tau

def get_v_star(tau_abs, epsilon):
    inner_cos = (epsilon * (5 * tau_abs - epsilon ** 2)) / (epsilon ** 2 + 5 * tau_abs) ** 1.5
    inner_cos = np.clip(inner_cos, -1, 1)
    return -epsilon / 5 + (2 / 5) * np.sqrt(epsilon ** 2 + 5 * tau_abs) * np.cos(1 / 3 * np.arccos(inner_cos))

def g_func(v, tau_abs, nu, epsilon):
    return v * (epsilon + v) ** 2 * (v ** 2 - tau_abs) + 0.5 * nu * epsilon * (epsilon + 1)

def bisection_tl12(tau_abs, nu, epsilon):
    v_min = get_v_star(tau_abs, epsilon)
    v_max = np.sqrt(tau_abs)
    a, b = v_min.copy(), v_max.copy()
    for _ in range(30):
        c = (a + b) / 2
        condition = g_func(a, tau_abs, nu, epsilon) * g_func(c, tau_abs, nu, epsilon) < 0
        b = np.where(condition, c, b)
        a = np.where(condition, a, c)
    return (a + b) / 2

def shrinkage_TL12(x0, epsilon, nu, k):
    x = np.zeros_like(x0)
    abs_x0 = np.abs(x0)
    bar_tau = get_bar_tau(nu, epsilon)
    index = abs_x0 > bar_tau
    if np.any(index):
        relevant_abs_x0 = abs_x0[index]
        v_tau = bisection_tl12(relevant_abs_x0, nu, epsilon)
        x[index] = np.sign(x0[index]) * (v_tau ** 2)
    return x


# TL1 shrinkage
def tau(a, Lambda):
    if Lambda <= a**2 / (2 * (a + 1)):
        t = Lambda * (a + 1) / a
    else:
        t = np.sqrt(2 * Lambda * (a+1))- a / 2
    return t

def varphi(x0, a, Lambda):
    return np.arccos(1 - 27 * Lambda * a * (a + 1) / (2 * (a + abs(x0)) ** 3))

def shrinkage_TL1(x0, a, Lambda, k):
    x = np.zeros((x0.shape[0], 1))
    t= tau(a, Lambda)
    index0 = abs(x0) > t
    abs_x0 = abs(x0[index0])
    varphi_val = varphi(x0[index0], a, Lambda)
    x[index0] = np.sign(x0[index0]) * (
            (2 / 3) * (a + abs_x0) * np.cos(varphi_val / 3) - 2 * a / 3 + abs_x0 / 3)
    return x


# log shrinkage
def q(Lambda, z, x, epsilon):
    return 1 / (2 * Lambda) * (x - z) ** 2 + np.log(1 + abs(x) / epsilon)

def r(z, Lambda, epsilon):
    return q(Lambda, z, r2(z, epsilon, Lambda), epsilon) - q(Lambda, z, 0, epsilon)

def r2(z, epsilon, Lambda):
    inner = 0.25 * (z + epsilon) ** 2 - Lambda
    return 0.5 * (z - epsilon) + np.sqrt(np.maximum(inner,0))

def bisection_lg(a, b, Lambda, epsilon):
    for i in range(30):
        c = (a + b) / 2
        if r(a, Lambda, epsilon) * r(c, Lambda, epsilon) < 0:
            b = c
        else:
            a = c
        if (b - a) < 1e-8:
            break
    return c

# def zstar(epsilon, Lambda):
#     return bisection_lg(2 * np.sqrt(Lambda) - epsilon, Lambda / epsilon, Lambda, epsilon)

def shrinkage_log_soft(x0, epsilon, Lambda, k):
    x = np.zeros((x0.shape[0], 1))
    index1 = abs(x0) > Lambda / epsilon
    x[index1] = np.sign(x0[index1]) * r2(abs(x0[index1]), epsilon, Lambda)
    return x

def shrinkage_log_hard(x0, epsilon, Lambda):
    z_star = bisection_lg(2 * np.sqrt(Lambda) - epsilon, Lambda / epsilon, Lambda, epsilon)
    x = np.zeros((x0.shape[0], 1))
    index1 = abs(x0) > z_star
    x[index1] = np.sign(x0[index1]) * r2(abs(x0[index1]), epsilon, Lambda)
    return x

def shrinkage_log(a_log, Lambda):
    if np.sqrt(Lambda) <= a_log:
        return shrinkage_log_soft
    else:
        return shrinkage_log_hard


# arctan shrinkage
# 要求 0 < Lambda < 8 * np.sqrt(3) / (9 * a**2)
def sinh(t):
    return (np.exp(t) - np.exp(-t)) / 2

def cosh(t):
    return (np.exp(t) + np.exp(-t)) / 2

def arcsinh(t):
    return np.log(t + np.sqrt(t**2 + 1))

def arccosh(t):
    t_clipped = np.maximum(t, 1.0)
    return np.log(t_clipped + np.sqrt(t_clipped ** 2 - 1))

def p_arc(tau,eps):
    return 1 / (3 * eps ** 2) - (tau ** 2) / 9

def q_arc(tau, eps, nu):
    return nu / (2 * eps) - tau / (3 * eps ** 2) - (tau ** 3) / 27

def r_arc(tau, eps, nu):
    abs_tau = np.abs(tau)
    q_val = q_arc(abs_tau, eps, nu)
    p_val = p_arc(abs_tau, eps)
    sign_q = np.sign(q_val)
    sqrt_abs_p = np.sqrt(np.abs(p_val))
    return sign_q * sqrt_abs_p

def v(tau, eps, nu):
    abs_tau = np.abs(tau)
    p_val = p_arc(abs_tau, eps)
    q_val = q_arc(abs_tau, eps, nu)
    r_val = r_arc(abs_tau, eps, nu)
    v_result = np.zeros_like(tau)
    # 分支1：p < 0（arccosh分支）
    mask_p_neg = p_val < 0
    # 处理r=0的情况：避免除零，直接除以无穷大使结果等于0（公式中p<0时r≠0，兜底）
    r_cubed = np.where(r_val[mask_p_neg] != 0, r_val[mask_p_neg] ** 3, np.inf)
    arg_arccosh = q_val[mask_p_neg] / r_cubed
    v_result[mask_p_neg] = arccosh(arg_arccosh)
    # 分支2：p > 0（arcsinh分支）
    mask_p_pos = p_val > 0
    r_cubed = np.where(r_val[mask_p_pos] != 0, r_val[mask_p_pos] ** 3, np.inf)
    arg_arcsinh = q_val[mask_p_pos] / r_cubed
    v_result[mask_p_pos] = arcsinh(arg_arcsinh)
    # p=0时v无定义，保持0（公式中p=0时h函数不依赖v）
    return v_result

def h(tau, eps, nu):
    h_res = np.zeros_like(tau)
    abs_tau = np.abs(tau)
    p_val = p_arc(abs_tau, eps)
    q_val = q_arc(abs_tau, eps, nu)
    r_val = r_arc(abs_tau, eps, nu)
    v_val = v(tau, eps, nu)
    # 分支1：p < 0
    mask_p_neg = p_val < 0
    h_res[mask_p_neg] = -2 * r_val[mask_p_neg] * cosh(v_val[mask_p_neg] / 3) + abs_tau[mask_p_neg] / 3
    # 分支2：p == 0（三次方根处理，保证实数结果）
    mask_p_zero = np.isclose(p_val, 0)  # 浮点精度兼容：不用==，用isclose
    arg_cbrt = -2 * q_val[mask_p_zero]
    # Python负数三次方根返回复数，用np.cbrt（原生支持实数三次方根）
    h_res[mask_p_zero] = np.cbrt(arg_cbrt) + abs_tau[mask_p_zero] / 3
    # 分支3：p > 0
    mask_p_pos = p_val > 0
    h_res[mask_p_pos] = -2 * r_val[mask_p_pos] * sinh(v_val[mask_p_pos] / 3) + abs_tau[mask_p_pos] / 3
    return h_res

def shrinkage_Arctan(x0, eps, nu, k):
    nu_upper = 8 * np.sqrt(3) / (9 * eps ** 2)
    if not (0 < nu < nu_upper):
        raise ValueError(f"nu必须满足0 < nu < {nu_upper:.4f}（当前nu={nu}）")
    abs_x0 = np.abs(x0)
    threshold = nu * eps
    prox_result = np.zeros_like(x0)
    # 分支1：|τ| ≤ νε → 返回0
    # mask_small = abs_x0 <= threshold
    # prox_result[mask_small] = 0
    # 分支2：|τ| > νε → 返回sign(τ) * bar_h(|τ|)
    mask_large = abs_x0 > threshold
    h_val = h(x0[mask_large], eps, nu)  # 计算h(|τ|)
    prox_result[mask_large] = np.sign(x0[mask_large]) * h_val
    return prox_result


# PiE shrinkage
def P(z, mu_Lambda, sigma):
    return 0.5 + mu_Lambda * ((z / sigma + 1) * np.exp(-z / sigma) - 1) / (z ** 2)

def bisection_PiE(a, b, mu_Lambda, sigma):
    for i in range(30):
        c = (a + b) / 2
        if P(a, mu_Lambda, sigma) * P(c, mu_Lambda, sigma) < 0:
            b = c
        else:
            a = c
        if (b - a) < 1e-8:
            break
    return c

def PiEProximalbyLambertWThreshold(x0, sigma, mu_Lambda):
    x = np.zeros((x0.shape[0], 1))
    xstar = bisection_PiE(1e-5, np.sqrt(2 * mu_Lambda)-1e-5, mu_Lambda, sigma)
    threshold = xstar + mu_Lambda / sigma * np.exp(-xstar / sigma)######修改########
    index = abs(x0) > threshold
    z = -(mu_Lambda / sigma ** 2) * np.exp(-abs(x0[index]) / sigma)
    lamb = lambertw(z, 0).real
    x[index] = np.sign(x0[index]) * (sigma * lamb + abs(x0[index]))
    return x

def shrinkage_PiE_soft(x0, sigma, mu_Lambda, k):
    x = np.zeros((x0.shape[0], 1))
    index = abs(x0) > mu_Lambda / sigma
    z = -(mu_Lambda / sigma ** 2) * np.exp(-abs(x0[index]) / sigma)
    x1 = sigma * lambertw(z, 0).real + abs(x0[index])
    x[index] = np.sign(x0[index]) * x1
    return x

def shrinkage_PiE(a_pie, Lambda):
    threshold = Lambda / a_pie ** 2
    if threshold <= 1:
        return shrinkage_PiE_soft
    else:
        return PiEProximalbyLambertWThreshold


# l0 shrinkage
def shrinkage_l0_topk(x0, a, Lambda, k):
    x = np.zeros_like(x0)
    abs_x0 = np.abs(x0.flatten())
    # 找到第 k 大的元素的阈值
    # np.partition 会将数组分为两部分，比第 n 大小的在左边，大的在右边
    # 我们找倒数第 k 个，即第 n-k 个
    threshold = np.partition(abs_x0, -k)[-k]
    # 保留大于等于该阈值的元素（注意处理并列情况，确保只留k个）
    mask = np.abs(x0) >= threshold
    x[mask] = x0[mask]
    return x


# l1 shrinkage
def shrinkage_l1(x0, a, Lambda, k):
    x = np.zeros((x0.shape[0], 1))
    index = abs(x0) > Lambda
    x[index] = np.sign(x0[index]) * (abs(x0[index]) - Lambda)
    return x


# l1/2 shrinkage
def shrinkage_l1over2(x0, a, Lambda,k):
    x = np.zeros_like(x0)
    # 阈值条件：|tau| > 3/2 * lambda^(2/3)
    threshold = 1.5 * np.power(Lambda, 2 / 3)
    index = np.abs(x0) > threshold
    if np.any(index):
        tau = x0[index]
        inner_val = - (Lambda / 4) * np.power(3 / np.abs(tau), 1.5)
        theta = np.arccos(inner_val)
        x[index] = (4 * tau / 3) * np.power(np.cos(theta / 3), 2)
    return x


# l2/3 shrinkage
def shrinkage_l2over3(x0,a,Lambda,k):
    x = np.zeros_like(x0)
    threshold = 2 * np.power(2 * Lambda / 3, 0.75)
    index = np.abs(x0) > threshold
    if np.any(index):
        tau = x0[index]
        abs_tau = np.abs(tau)
        discriminant = np.power(tau, 4) / 256 - 8 * np.power(Lambda, 3) / 729
        sqrt_disc = np.sqrt(np.maximum(discriminant, 0))
        t1 = np.power(tau, 2) / 16 + sqrt_disc
        t2 = np.power(tau, 2) / 16 - sqrt_disc
        s = np.power(t1, 1 / 3) + np.power(t2, 1 / 3)
        sqrt_2s = np.sqrt(2 * s)
        inner_bracket = sqrt_2s + np.sqrt(np.maximum(2 * abs_tau / sqrt_2s - 2 * s, 0))
        x[index] = (1 / 8) * np.sign(tau) * np.power(inner_bracket, 3)
    return x

##############################  Lambda形状参数；nu邻近算子参数；tau输入向量  ##############################
#########################  CL1：lambda^2/nu>0.5；CL1/2&2/3：lambda^2/nu>=1.5  ##########################
# CL1 shrinkage
def shrinkage_CaP1(x0, Lambda, nu, k):
    x = np.zeros((x0.shape[0], 1))
    index0 = np.logical_and(nu/Lambda<abs(x0),abs(x0) <= Lambda+nu/(2*Lambda))
    index1 = abs(x0) > Lambda+nu/(2*Lambda)
    x[index0] = x0[index0]-np.sign(x0[index0])*nu/Lambda
    x[index1] = x0[index1]
    return x


# CL1/2 shrinkage
C_PROX12_CONST = (3 * math.sqrt(3)) / 4 
def J(q,nu,Lambda,u,tau):
    return nu*np.minimum(1.0,np.power(np.abs(u)/Lambda,q)) + 0.5 * (u -tau)**2

def J_scalar(q, nu, Lambda, u, tau):
    """纯标量版本的 J 函数，去除了 NumPy 数组开销"""
    val = abs(u) / Lambda
    # np.minimum 的标量替代
    term1 = val ** q if val < 1.0 else 1.0
    return nu * term1 + 0.5 * (u - tau) ** 2

def ProxL1over2_scalar(nu, tau):
    """纯标量版本的 ProxL1over2，专供二分法使用"""
    abs_tau = abs(tau)
    threshold = 1.5 * (nu ** (2/3))
    if abs_tau > threshold:
        theta = math.acos(-C_PROX12_CONST * nu * (abs_tau ** -1.5))
        return (2 / 3) * tau * (1 + math.cos((2 * theta) / 3))
    return 0.0

def bisection_CL1over2(a, b, q, nu, Lambda):
    """优化后的二分法，减少了 50% 的函数调用"""
    nu_scaled = nu / (Lambda ** q)
    # 缓存端点 a 的函数值，避免在循环中重复计算
    u_a = ProxL1over2_scalar(nu_scaled, a)
    fa = J_scalar(q, nu, Lambda, u_a, a) - nu
    for _ in range(10):
        c = (a + b) / 2
        u_c = ProxL1over2_scalar(nu_scaled, c)
        fc = J_scalar(q, nu, Lambda, u_c, c) - nu 
        if fa * fc < 0:
            b = c
        else:
            a = c
            fa = fc  # 关键：更新缓存的 fa，避免下次重新计算 a
        if (b - a) < 1e-5:
            break     
    return (a + b) / 2

def ProxL1over2_array(nu, tau):
    """优化后的数组版本，供最终矩阵收缩使用"""
    ytilde = np.zeros_like(tau)
    abs_tau = np.abs(tau)
    threshold = 1.5 * (nu ** (2/3))
    condition = abs_tau > threshold 
    # 如果没有满足条件的元素，直接返回全零，节省时间
    if not np.any(condition):
        return ytilde 
    tau_cond = tau[condition]
    abs_tau_cond = abs_tau[condition]
    theta = np.arccos(-C_PROX12_CONST * nu * (abs_tau_cond ** -1.5))
    ytilde[condition] = (2 / 3) * tau_cond * (1 + np.cos((2 * theta) / 3))
    return ytilde

def shrinkage_CaP1over2(x0, Lambda, nu, k):
    x = x0.copy() 
    sqrt_Lambda = math.sqrt(Lambda)
    nu_scaled = nu / sqrt_Lambda
    cnulambda_1over2 = 1.5 * (nu_scaled ** (2/3))
    C_nulambda_1over2 = bisection_CL1over2(cnulambda_1over2, Lambda + 0.5 * nu / Lambda, 0.5, nu, Lambda)
    index0 = np.abs(x0) < C_nulambda_1over2
    x[index0] = ProxL1over2_array(nu_scaled, x0[index0])
    return x


# CL2/3 shrinkage
def real_cbrt(x):
    """实数域下的立方根函数，避免产生复数"""
    return x**(1/3) if x >= 0 else -(-x)**(1/3)

def ProxL2over3_scalar(nu, tau):
    """纯标量版本的 ProxL2over3，用于二分法的高效计算"""
    abs_tau = abs(tau)
    threshold = 2 * ((2 * nu / 3) ** 0.75)
    if abs_tau > threshold:
        tau2 = tau ** 2
        # t1 = sqrt(tau^4/256 - 8*nu^3/729)
        # 注意：在阈值外，根号下理论上始终大于0
        t1 = math.sqrt(max(0, (tau2**2) / 256 - 8 * (nu**3) / 729))
        term_plus = tau2 / 16 + t1
        term_minus = tau2 / 16 - t1
        # 计算 t = 2 * ( (tau^2/16 + t1)^(1/3) + (tau^2/16 - t1)^(1/3) )
        t = 2 * (real_cbrt(term_plus) + real_cbrt(term_minus))  
        sqrt_t = math.sqrt(t)
        # 最终公式
        res = (1/8) * (sqrt_t + math.sqrt(max(0, 2 * abs_tau / sqrt_t - t))) ** 3
        return math.copysign(res, tau)
    return 0.0

def bisection_CL2over3(a, b, q, nu, Lambda):
    """优化后的二分法，专为 L2/3 临界点设计"""
    nu_scaled = nu / (Lambda ** q)
    # 缓存 fa 减少 50% 计算量
    u_a = ProxL2over3_scalar(nu_scaled, a)
    fa = J_scalar(q, nu, Lambda, u_a, a) - nu
    for _ in range(10):
        c = (a + b) / 2
        u_c = ProxL2over3_scalar(nu_scaled, c)
        fc = J_scalar(q, nu, Lambda, u_c, c) - nu
        if fa * fc < 0:
            b = c
        else:
            a = c
            fa = fc         
        if (b - a) < 1e-5:
            break     
    return (a + b) / 2

def ProxL2over3_array(nu, tau):
    """优化后的数组版本，使用 NumPy 向量化运算"""
    ytilde = np.zeros_like(tau)
    abs_tau = np.abs(tau)
    threshold = 2 * ((2 * nu / 3) ** 0.75)
    condition = abs_tau > threshold
    if not np.any(condition):
        return ytilde      
    tau_c = tau[condition]
    abs_tau_c = abs_tau[condition]
    tau2 = tau_c ** 2
    # 向量化计算 t1
    t1 = np.sqrt(np.maximum(0, (tau2**2) / 256 - 8 * (nu**3) / 729))
    tp = tau2 / 16 + t1
    tm = tau2 / 16 - t1
    # NumPy 的 cbrt 专门用于处理实数立方根，比 **(1/3) 更稳健
    t = 2 * (np.cbrt(tp) + np.cbrt(tm))
    sqrt_t = np.sqrt(t)
    # ytilde 计算
    res = (1/8) * (sqrt_t + np.sqrt(np.maximum(0, 2 * abs_tau_c / sqrt_t - t))) ** 3
    ytilde[condition] = np.sign(tau_c) * res
    return ytilde

def shrinkage_CaP2over3(x0, Lambda, nu, k):
    """优化后的主函数"""
    x = x0.copy()
    # q=2/3
    q = 2/3
    Lambda_q = Lambda ** q
    nu_scaled = nu / Lambda_q
    # 计算初始搜索范围
    cnulambda_2over3 = 2 * (( (2/3) * nu / Lambda_q ) ** 0.75)
    # 获取二分法计算的算子切换阈值
    C_nulambda = bisection_CL2over3(cnulambda_2over3, Lambda + (2/3) * nu / Lambda, q, nu, Lambda)
    # 执行收缩
    mask = np.abs(x0) < C_nulambda
    if np.any(mask):
        x[mask] = ProxL2over3_array(nu_scaled, x0[mask])
    return x