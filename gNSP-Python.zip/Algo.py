import numpy as np

#Indicator function
def shrinkage_indicator(x0, A, b):
    return x0 - A.T @ (A @ x0 - b)


def DRS_k(A, b, rho, shrinkage, a, k, maxiter, x_true=None, z0_init=None):
    n = A.shape[1]    
    # 引入热启动：如果提供了初始点，则使用该点；否则使用零向量
    if z0_init is not None:
        z0 = z0_init.copy()
    else:
        z0 = np.zeros((n, 1)) 
    rel_errors = []
    record_error = x_true is not None
    gamma = 0.5
    for l in range(maxiter):
        x1 = shrinkage(z0, a, rho, k)
        y1 = shrinkage_indicator(2 * x1 - z0, A, b)
        z1 = z0 + gamma * (y1 - x1)
        z0 = z1
        if rho > 1e-4:
            rho = 0.98 * rho
        if record_error:
            rel_error = np.linalg.norm(x1 - x_true) / np.linalg.norm(x_true)
            rel_errors.append(rel_error)
    if record_error:
        return x1, l + 1, rel_errors
    else:
        return x1, l + 1


def IHT_warm_start(A, b, k, mu, shrinkage_l0_topk, maxiter):
    n = A.shape[1]
    x = np.zeros((n, 1))

    for _ in range(maxiter):
        gradient = A.T @ (A @ x - b)
        x_unthresholded = x - mu * gradient
        x = shrinkage_l0_topk(x_unthresholded, a=0, Lambda=0, k=k)
    return x


from scipy.fft import dct   

def generate_partial_dct_matrix(m, n, type=2, norm='ortho'):
    """
    生成 m×n 的部分 DCT 矩阵 (实数)
    
    参数:
        m : 测量数
        n : 信号长度
        type : DCT 类型，默认 2（常用 DCT-II）
        norm : 归一化方式，'ortho' 表示正交矩阵（行向量模长为1）
    返回:
        A : shape (m, n) 的实数矩阵，每一行对应一个随机选取的 DCT 频率分量
    """    
    # 生成 n×n 的正交 DCT 矩阵：对单位矩阵的每一列做一维 DCT
    I = np.eye(n)
    # axis=0 表示沿列方向变换，即对每个标准基向量做 DCT
    D = dct(I, type=type, axis=0, norm=norm)
    # 随机选择 m 个不同的频率行
    rows = np.random.choice(n, size=m, replace=False)
    A = D[rows, :]
    return A


def coherence(A):
    # 1. 列归一化
    norms = np.linalg.norm(A, axis=0)
    A_norm = A / norms
    # 2. Gram matrix
    G = A_norm.T @ A_norm
    # 3. 去掉对角线
    np.fill_diagonal(G, 0)
    # 4. 最大绝对非对角元素
    mu = np.max(np.abs(G))
    return mu


def Error(x, x_true):# Calculate the Error
    return (np.linalg.norm(x-x_true)/np.linalg.norm(x_true))

